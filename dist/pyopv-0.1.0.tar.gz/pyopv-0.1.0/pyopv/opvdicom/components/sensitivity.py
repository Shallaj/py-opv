class OPVDicomSensitivity:
    """Class representing the sensitivities of an OPV DICOM"""

    def __init__(self):
        pass